import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Interview {

	public static void main(String[] args) {
		HashSet<Integer> set = new HashSet<Integer>();
		set.add(0);
		set.add(1);
		set.add(2);
		set.add(3);
		set.add(4);

		ArrayList<Integer> arr = new ArrayList<Integer>();
		arr.add(0);
		arr.add(1);
		arr.add(2);
		arr.add(3);
		arr.add(4);
		arr.add(5);
		
		reverseArrayInPlace(arr);
		System.out.println(arr);

		ArrayList<Meeting> meetings = new ArrayList<Meeting>();
		Meeting meeting1 = new Meeting("meeting1", 1);
		Meeting meeting2 = new Meeting("meeting2", 2);
		Meeting meeting3 = new Meeting("meeting3", 3);
		Meeting meeting4 = new Meeting("meeting4", 4);
		Meeting meeting5 = new Meeting("meeting5", 5);

		meetings.add(meeting2);
		meetings.add(meeting5);
		meetings.add(meeting1);
		meetings.add(meeting4);
		meetings.add(meeting3);

		ArrayList<Integer> arr2 = new ArrayList<Integer>();
		arr2.add(1);
		arr2.add(1);
		arr2.add(2);
		arr2.add(2);
		arr2.add(3);

		// System.out.println(thirdSmallest(set));
		// System.out.println(sameWord("HELLO", "hello"));
		// System.out.println(continguousThree(arr, 4));
		// System.out.println(Fibonacci(new ArrayList<Integer>(), 1, 1, 100));
//		for (int i = 50; i < 1000; i++) {
//			String sentence = "The number " + i + " is " + isPrime(i);
//			System.out.println(sentence);
//		}

		// System.out.println(primes(1, 10000000));
//		maxMeetings(meetings, 15);
//		for (int i = 0; i < 5; i++) {
//			System.out.println(meetings.get(i).getName());
//		}
//		String reversed = reverseString("Dick");
//		System.out.println(reversed);

		// System.out.println(removeDuplicates(arr2));

	}

	public static int thirdSmallest(Set<Integer> numbers) {

		ArrayList<Integer> arr = new ArrayList<Integer>();
		Iterator<Integer> iterator = numbers.iterator();

		while (iterator.hasNext()) {
			arr.add(iterator.next());
		}
		arr.sort(null);

		return arr.get(2);

	}

	public static boolean sameWord(String word1, String word2) {

		if (word1.toLowerCase().equals(word2.toLowerCase())) {

			return true;
		}

		return false;
	}

	public static ArrayList<Integer> continguousThree(ArrayList<Integer> arr, int k) {

		ArrayList<Integer> array1 = new ArrayList<Integer>();
		ArrayList<Integer> array2 = new ArrayList<Integer>();
		int tracker = 0;

		// This adds the first k elements to array1.
		for (int i = 0; i < k; i++) {
			array1.add(arr.get(i));
			tracker++;
		}

		// This adds k elements to array 2, then when the array is k elements full it
		// compares
		// array 1 and 2. If 1 is smaller, they switch. Regardless of switch, array2 is
		// cleared and fills again.
		for (int j = tracker; tracker < arr.size(); j++) {
			array2.add(arr.get(j));
			if (j % k == 0) {
				for (int q = 0; q < k; q++) {
					if (array1.get(q) < array2.get(q)) {
						array1 = array2;
						array2.clear();
						break;
					}

					else {
						array2.clear();
					}
				}

			}

		}

		// int arrSize = arr.size() / k;

		return array1;
	}

	public static ArrayList<Integer> Fibonacci(ArrayList<Integer> arr, int one, int two, int end) {

		if (one + two > end) {
			return arr;
		}

		if (arr.isEmpty()) {
			arr.add(one);
			arr.add(two);
			arr.add(one + two);
		}

		else {
			arr.add(one + two);
		}

		Fibonacci(arr, two, one + two, end);

		return arr;
	}

	public static String isPrime(int n) {

		double checkTo = Math.sqrt(n);

		int[] firstPrimes = { 2, 3, 5, 7, 13, 17, 19, 23, 29, 31, 37 };

		for (int i = 0; i < firstPrimes.length; i++) {
			if (firstPrimes[i] == n)
				return "prime";
		}

		for (int i = 0; i < firstPrimes.length; i++) {
			if (n % firstPrimes[i] == 0)
				return "composite";
		}

		for (int j = 38; j < checkTo; j++) {
			if (n % j == 0)
				return "composite";
		}

		return "prime";
	}

	public static ArrayList<Integer> primes(int start, int end) {
		ArrayList<Integer> arr = new ArrayList<Integer>();

		for (int i = start; i < end; i++) {
			if (isPrime(i) == "prime") {
				arr.add(i);
			}
		}

		return arr;
	}

	public static ArrayList<Meeting> maxMeetings(ArrayList<Meeting> arr, float hours) {

		ArrayList<Meeting> meetings = new ArrayList<Meeting>();

		arr.sort(new sortByHours());

		return meetings;

	}

	public static String reverseString(String word) {
		StringBuilder builder = new StringBuilder();

		for (int i = word.length() - 1; i >= 0; i--) {
			builder.append(word.charAt(i));
		}

		String reversed = builder.toString();

		return reversed;
	}

	public static ArrayList<Integer> removeDuplicates(ArrayList<Integer> arr) {
		HashSet<Integer> set = new HashSet<Integer>();
		for (int i = 0; i < arr.size(); i++) {
			set.add(arr.get(i));
		}
		arr.clear();
		Iterator<Integer> it = set.iterator();
		while (it.hasNext()) {
			arr.add(it.next());
		}

		return arr;
	}

	public static ArrayList<Integer> reverseArrayInPlace(ArrayList<Integer> arr) {
		int j = arr.size() - 1;
		for (int i = 0; i < arr.size() / 2; i++) {
			swap(arr, i, j);
			j--;
		}

		return arr;
	}

	public static void swap(ArrayList<Integer> arr, int index1, int index2) {
		int holder = arr.get(index1);
		arr.set(index1, arr.get(index2));
		arr.set(index2, holder);
	}

}

class sortByHours implements Comparator<Meeting> {
	// Used for sorting in ascending order of
	// roll number
	public int compare(Meeting a, Meeting b) {
		return (int) (a.getHours() - b.getHours());
	}
}
