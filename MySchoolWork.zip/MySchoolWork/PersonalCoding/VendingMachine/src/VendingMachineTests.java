import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

class VendingMachineTests {
	VendingItem candy = new VendingItem("candy", 10.0);
	VendingItem snack = new VendingItem("snack", 50.0);
	VendingItem nuts = new VendingItem("nuts", 90.0);
	VendingItem coke = new VendingItem("coke", 25.0);
	VendingItem pepsi = new VendingItem("pepsi", 35.0);
	VendingItem soda = new VendingItem("soda", 45.0);
	ArrayList<VendingItem> stock = new ArrayList<VendingItem>();
	
	@Test
	void testContainsAndAdd() {
		
		stock.add(candy);
		stock.add(snack);
		stock.add(nuts);
		stock.add(coke);
		stock.add(pepsi);
		VendingMachine machine = new VendingMachine(stock);
		machine.addVendingItem(soda);
		Assert.assertTrue(machine.contains(soda));
	}
	
	//The machine only takes 1 and 2 dollar bills.
	@Test
	void testAddMoney() {
		stock.add(candy);
		stock.add(snack);
		stock.add(nuts);
		stock.add(coke);
		stock.add(pepsi);
		stock.add(soda);
		VendingMachine machine = new VendingMachine(stock);
		
		machine.addMoney(10.0);
		
		assertEquals(0, machine.getCurrentBalance(), 0.01);
	}
	
	@Test
	void testAddMoney2() {
		stock.add(candy);
		stock.add(snack);
		stock.add(nuts);
		stock.add(coke);
		stock.add(pepsi);
		stock.add(soda);
		VendingMachine machine = new VendingMachine(stock);
		
		machine.addMoney(2.0);
		assertEquals(2, machine.getCurrentBalance(), 0.01);
		
		machine.addMoney(0.01);
		assertEquals(2.01, machine.getCurrentBalance(), 0.01);
		
		machine.addMoney(0.05);
		assertEquals(2.06, machine.getCurrentBalance(), 0.01);
		
		machine.addMoney(.10);
		assertEquals(2.16, machine.getCurrentBalance(), 0.01);
		
		machine.addMoney(.25);
		assertEquals(2.41, machine.getCurrentBalance(), 0.01);
		
		machine.addMoney(.50);
		assertEquals(2.91, machine.getCurrentBalance(), 0.01);
		
		machine.addMoney(1.0);
		assertEquals(3.91, machine.getCurrentBalance(), 0.01);
		
		machine.addMoney(5.0);
		assertEquals(3.91, machine.getCurrentBalance(), 0.01);
	}

}


//Allow user to select products e.g. CANDY(10), SNACK(50), NUTS(90), Coke(25), Pepsi(35), Soda(45)