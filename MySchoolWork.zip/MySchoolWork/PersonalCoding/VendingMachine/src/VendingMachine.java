import java.util.ArrayList;

public class VendingMachine {
	private double currentBalance;
	private static double vendingBalance;
	ArrayList<VendingItem> stock;

	public VendingMachine(ArrayList<VendingItem> arr) {
		currentBalance = 0.0;
		vendingBalance = 0.0;
		stock = arr;

	}

	public void addMoney(double amount) {

		if (amount == 0.01 || amount == 0.05 || amount == .10 || amount == 0.25 || amount == 0.50 || amount == 1.0
				|| amount == 2.0) {

			currentBalance += amount;
			vendingBalance += amount;
		}
	}

	public double refund() {

		double holder = currentBalance;
		currentBalance = 0.0;
		return holder;
	}

	public VendingItem buyItem(VendingItem item) {
		if (!stock.contains(item)) {
			return null;
		}

		else {
			if (currentBalance >= item.getPrice()) {
				stock.remove(item);
				currentBalance -= item.getPrice();
				refund();
				return item;
			}

			else {
				return null;
			}
		}

	}

	public void addVendingItem(VendingItem item) {
		stock.add(item);
	}

	public void reset() {
		currentBalance = 0.0;
		vendingBalance = 0.0;
		stock = new ArrayList<VendingItem>();
	}

	public boolean contains(VendingItem item) {
		if (stock.contains(item))
			return true;

		else
			return false;
	}

	public double getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(double currentBalance) {
		this.currentBalance = currentBalance;
	}

	public static double getVendingBalance() {
		return vendingBalance;
	}

	public static void setVendingBalance(double vendingBalance) {
		VendingMachine.vendingBalance = vendingBalance;
	}

	public ArrayList<VendingItem> getStock() {
		return stock;
	}

	public void setStock(ArrayList<VendingItem> stock) {
		this.stock = stock;
	}

}

//You need to design a Vending Machine which follows following requirements
//Accepts coins of 1,5,10,25, 50 Cents i.e. penny, nickel, dime, and quarter as well as 1 and 2 dollar note
//Allow user to select products e.g. CANDY(10), SNACK(50), NUTS(90), Coke(25), Pepsi(35), Soda(45)
//Allow user to take refund by canceling the request.
//Return selected product and remaining change if any
//Allow reset operation for vending machine supplier