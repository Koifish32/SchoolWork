
public interface Funcitonal {
	
	public void function();

}


//the engine, the fuel tank, the wheels
