import java.util.Random;

public class CarPart implements Funcitonal {
	int condition;
	Random r = new Random();
	
	public CarPart(int condition) {
		this.condition = condition;
	}
	
	public void status() {
		System.out.println("The condition of this piece is at: " + condition);
	}

	@Override
	public void function() {
		// TODO Auto-generated method stub
		System.out.println("Test");
		
	}

}
