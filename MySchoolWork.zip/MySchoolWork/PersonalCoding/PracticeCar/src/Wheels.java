import java.util.ArrayList;
import java.util.Random;

public class Wheels extends CarPart {
	int condition;
	Random r = new Random();
	ArrayList<String> arr = new ArrayList<String>();

	public Wheels(int condition) {
		super(condition);
		this.condition = condition;
		arr.add("boring");
		arr.add("average");
		arr.add("some real fancy");
	}
	
	public void rims() {
		
		
		
		System.out.println("This car has" + arr.get(r.nextInt(3)) + "rims" );
		
		
	
	}
	
	public void function() {
		System.out.println("This car has " + arr.get(r.nextInt(3)) + " rims" );
		
	}

}
