import java.util.Random;

public class Engine extends CarPart {

	int condition;
	Random r = new Random();

	public Engine(int condition) {
		super(condition);
		this.condition = condition;
	}
	
	public void function() {
		System.out.println("This engine has " + (r.nextInt(6) + 1) + " cylinders");
		
	}

}
