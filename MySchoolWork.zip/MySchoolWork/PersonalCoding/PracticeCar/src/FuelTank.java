import java.util.Random;

public class FuelTank extends CarPart {
	int condition;
	Random r = new Random();

	public FuelTank(int condition) {
		super(condition);
		this.condition = condition;
	}

	public void function() {
		System.out.println("This tank holds " + (r.nextInt(11) * 10) + " gallons of fuel");

	}

}
