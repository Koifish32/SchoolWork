
public class Simulator {
	
	static Engine engineA = new Engine(100);
	static FuelTank fueltankA = new FuelTank(100);
	static Wheels wheelsA = new Wheels(100);
	
	static Engine engineB = new Engine(100);
	static FuelTank fueltankB = new FuelTank(100);
	static Wheels wheelsB = new Wheels(100);
	
	
	public static void main(String[] args) {
		Car carA = new Car(engineA, fueltankA, wheelsA);
		Car carB = new Car(engineB, fueltankB, wheelsB);
		
		carA.run();
		carB.run();
		

	}

}
