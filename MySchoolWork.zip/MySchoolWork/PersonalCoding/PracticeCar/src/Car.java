import java.util.ArrayList;

public class Car {
	Engine engine;
	FuelTank fueltank;
	Wheels wheels;

	public Car(Engine engine, FuelTank fueltank, Wheels wheels) {
		this.engine = engine;
		this.fueltank = fueltank;
		this.wheels = wheels;

	}

	public void run() {
		ArrayList<CarPart> parts = new ArrayList<>();
		parts.add(engine);
		parts.add(fueltank);
		parts.add(wheels);

		for (int i = 0; i < parts.size(); i++) {
			CarPart tempObject = parts.get(i);
			tempObject.function();

		}

	}

}
