import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;

public class Menu extends MouseAdapter {

	private Game game;
	private Handler handler;
	private HUD hud;
	Random r = new Random();

	public Menu(Game game, Handler handler, HUD hud) {
		this.game = game;
		this.handler = handler;
		this.hud = hud;
	}

	public void mousePressed(MouseEvent e) {
		int mx = e.getX();
		int my = e.getY();

		if (game.gameState == game.gameState.Menu) {
			// Play game button
			if (mouseOver(mx, my, Game.HEIGHT / 2, 240, 200, 64)) {
				game.gameState = Game.STATE.Game;
				handler.clearEnemys();
			}
			// Help button
			else if (mouseOver(mx, my, Game.HEIGHT / 2, 320, 200, 64)) {
				game.gameState = Game.STATE.Help;
			}
			// Quit button
			else if (mouseOver(mx, my, Game.HEIGHT / 2, 400, 200, 64)) {
				System.exit(1);
			}

		}
		
		//Try again button
		else if (game.gameState == game.gameState.DeathScreen) {
			if (mouseOver(mx, my, 230, 400, 400, 128)) {
				game.gameState = Game.STATE.Game;
				hud.HEALTH = 100;
				hud.score(0);
				hud.setLevel(1);
			}
		}
		//Back button for Help menu
		else if (game.gameState == game.gameState.Help) {
			if (mouseOver(mx, my, Game.HEIGHT / 2, 400, 200, 64)) {
				game.gameState = Game.STATE.Menu;
				return;
			}
		}

	}

	public void mouseReleased(MouseEvent e) {

	}

	private boolean mouseOver(int mx, int my, int x, int y, int width, int height) {
		if (mx > x && mx < x + width) {
			if (my > y && my < y + height)
				return true;
			else
				return false;
		} else
			return false;

	}

	public void tick() {

	}

	public void render(Graphics g) {
		if (game.gameState == Game.STATE.Menu) {
			Font fnt = new Font("arial", 1, 50);
			g.setFont(fnt);
			;
			g.setColor(Color.WHITE);

			g.drawString("Quit", Game.HEIGHT / 2 + 35, 450);
			g.setColor(Color.WHITE);
			g.drawRect(Game.HEIGHT / 2, 400, 200, 64);

			g.drawString("Help", Game.HEIGHT / 2 + 45, 370);
			g.setColor(Color.WHITE);
			g.drawRect(Game.HEIGHT / 2, 320, 200, 64);

			g.drawString("Play", Game.HEIGHT / 2 + 50, 290);
			g.setColor(Color.WHITE);
			g.drawRect(Game.HEIGHT / 2, 240, 200, 64);
		}

		else if (game.gameState == Game.STATE.Help) {
			Font fnt = new Font("arial", 1, 50);
			g.setFont(fnt);
			;

			g.setColor(Color.WHITE);
			g.drawString("Use the arrow keys to move", Game.HEIGHT / 2 - 260 + 35, 200);

			g.setColor(Color.WHITE);
			g.drawString("AND DODGE!", Game.HEIGHT / 2 - 100 + 35, 300);
			//Back button for Help menu
			g.setColor(Color.WHITE);
			g.drawString("Back", Game.HEIGHT / 2 + 35, 450);
			g.setColor(Color.WHITE);
			g.drawRect(Game.HEIGHT / 2, 400, 200, 64);
		}

		else if (game.gameState == Game.STATE.DeathScreen) {
			handler.clearEnemys();


			Font fnt = new Font("arial", 1, 50);
			g.setFont(fnt);

			g.setColor(Color.RED);
			g.drawString("YOU DIED!", 300, 100);
			g.drawString("Your score was: " + hud.getScore() + " on level " + hud.getLevel(), 50, 200);

			g.setColor(Color.WHITE);
			g.drawString("Try Again?", 300, 480);
			g.drawRect(230, 400, 400, 128);
		}
	}

}
