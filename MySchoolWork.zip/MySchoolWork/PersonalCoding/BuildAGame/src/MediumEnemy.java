import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;
import java.util.Random;

public class MediumEnemy extends GameObject {
	
	private Handler handler;
	private Random r = new Random();
	LinkedList<Color> colors = new LinkedList<Color>();


	public MediumEnemy(int x, int y, ID id, Handler handler) {
		super(x, y, id,"enemy");
		
		this.handler = handler;
		velX = 7;
		velY = 7;
	}



	@Override
	public void render(Graphics g) {
		g.setColor(Color.ORANGE);
		g.fillRect((int)x,(int) y, 16, 16);
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle((int)x,(int) y, 32, 32);
	}
	
	@Override
	public void tick() {
		x += velX;
		y += velY;
		
		if(y <= 0 || y >= Game.HEIGHT) velY *= -1;
		if(x <= 0 || x >= Game.WIDTH) velX *= -1;
		
		
		colors.add(Color.RED);
		colors.add(Color.ORANGE);
		colors.add(Color.YELLOW);
		colors.add(Color.MAGENTA);
		
		handler.addObject(new Trail((int)x,(int)y,ID.Trail,Color.ORANGE, 10, 10, (float)0.5, handler));
		
	}
	

}
