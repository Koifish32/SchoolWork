import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;
import java.util.Random;

public class ComplexEnemy extends GameObject {

	private Handler handler;
	private Random r = new Random();
	LinkedList<Color> colors = new LinkedList<Color>();
	private GameObject player;

	public ComplexEnemy(int x, int y, ID id, Handler handler) {
		super(x, y, id, "enemy");

		this.handler = handler;

		for (int i = 0; i < handler.object.size(); i++) {
			if (handler.object.get(i).getID() == ID.Player) {
				player = handler.object.get(i);
			}
		}

	}

	@Override
	public void render(Graphics g) {
		g.setColor(Color.BLUE);
		g.fillRect((int)x, (int)y, 16, 16);
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle((int)x, (int)y, 32, 32);
	}

	@Override
	public void tick() {
		x += velX;
		y += velY;
		
		float diffX = x - player.getX() - 8;
		float diffY = y - player.getY() - 8;
		float distance = (float) Math.sqrt((x - player.getX()) * ((x - player.getX())) + (y - player.getY()) * (y - player.getY()));
		velX = ((-1/distance) * diffX) * 2;
		velY = ((-1/distance) * diffY) * 2;
		

		
		handler.addObject(new Trail((int)x,(int)y,ID.Trail,Color.BLUE, 16, 16, (float)0.05, handler));
		
	}

}
