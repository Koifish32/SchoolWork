import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;
import java.util.Random;

public class BasicEnemy extends GameObject {
	
	private Handler handler;
	private Random r = new Random();
	LinkedList<Color> colors = new LinkedList<Color>();


	public BasicEnemy(int x, int y, ID id, Handler handler) {
		super(x, y, id, "enemy");
		
		this.handler = handler;
		velX = 5;
		velY = 5;
	}



	@Override
	public void render(Graphics g) {
		g.setColor(Color.BLUE);
		g.fillRect((int)x, (int)y, 16, 16);
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle((int)x, (int)y, 32, 32);
	}
	
	@Override
	public void tick() {
		x += velX;
		y += velY;
		
		if(y <= 0 || y >= Game.HEIGHT) velY *= -1;
		if(x <= 0 || x >= Game.WIDTH) velX *= -1;
		
		
		colors.add(Color.RED);
		colors.add(Color.ORANGE);
		colors.add(Color.YELLOW);
		colors.add(Color.MAGENTA);
		
		handler.addObject(new Trail((int)x,(int)y,ID.Trail,Color.YELLOW, 16, 16, (float)0.05, handler));
		
	}
	

}
