import java.util.Random;

public class Spawn {
	private Handler handler;
	private HUD hud;
	private int scoreKeep = 0;
	private Random r = new Random();

	float posX;
	float posY;

	public Spawn(Handler handler, HUD hud) {
		this.handler = handler;
		this.hud = hud;
	}

	public void tick() {
		scoreKeep++;
		if (scoreKeep >= 100) {
			scoreKeep = 0;
			hud.setLevel(hud.getLevel() + 1);

			for (int i = 0; i < handler.object.size(); i++) {
				GameObject tempObject = handler.object.get(i);
				if (tempObject.getType() == "player") {
					posX = tempObject.getX();
					posY = tempObject.getY();
				}
			}

			if (hud.getLevel() <= 19) {
				


				if (hud.getLevel() == 2) {
					handler.addObject(
							new BasicEnemy(r.nextInt(Game.WIDTH), r.nextInt(Game.HEIGHT), ID.BasicEnemy, handler));
					
					handler.addObject(
							new BasicEnemy(r.nextInt(Game.WIDTH), r.nextInt(Game.HEIGHT), ID.BasicEnemy, handler));
					handler.addObject(new FroggerEnemy(1, 1, ID.FroggerEnemy, handler));


				}

				if (hud.getLevel() <= 10)
					handler.addObject(
							new BasicEnemy(r.nextInt(Game.WIDTH), r.nextInt(Game.HEIGHT), ID.BasicEnemy, handler));

				if (hud.getLevel() == 2)
					handler.addObject(
							new MediumEnemy(r.nextInt(Game.WIDTH), r.nextInt(Game.HEIGHT), ID.MediumEnemy, handler));

				if (hud.getLevel() == 5)
					handler.addObject(
							new ComplexEnemy(r.nextInt(Game.WIDTH), r.nextInt(Game.HEIGHT), ID.ComplexEnemy, handler));
			}

			if (hud.getLevel() == 10) {

				handler.clearEnemys();
				handler.addObject(new BossOne((Game.WIDTH / 2) - 48, -110, ID.BossOne, handler));
			}

			if (hud.getLevel() == 19) {
				handler.clearEnemys();
			}
		}

	}
}
