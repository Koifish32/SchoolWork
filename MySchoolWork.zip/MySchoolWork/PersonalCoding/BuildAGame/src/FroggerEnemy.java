import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;
import java.util.Random;

public class FroggerEnemy extends GameObject {

	private Handler handler;
	private Random r = new Random();
	LinkedList<Color> colors = new LinkedList<Color>();

	private boolean flag = false;
	private boolean velXStart = false;

	public FroggerEnemy(int x, int y, ID id, Handler handler) {
		super(x, y, id, "enemy");

		this.handler = handler;
		velX = 0;
		velY = 5;
	}

	@Override
	public void render(Graphics g) {
		g.setColor(Color.GREEN);
		g.fillRect((int) x, (int) y, 16, 16);
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle((int) x, (int) y, 32, 32);
	}

	@Override
	public void tick() {
		x += velX;
		y += velY;

		//Frogger enemy starts with a positive Y velocity, once it hits the ground at 540, it is given a negative velocity
		//to simulate jumping.
		if ((int) y >= 540) {
			velY = -2;
			flag = true;

		}

		//This is the top of the "jump" where gravity kicks in and the Frogger enemy falls to the ground.
		if (flag == true && (int) y <= 400) {
			velY = 2;
		}
		
		//Starts the Frogger enemy in the X direction after he has hit the ground.
		if (flag) {
			if (!velXStart) {
				velX = 2;
				velXStart = true;
			}
		}

		//Keeps the Frogger enemy from going beyond the screen limits in the x direction.
		if (flag)
			if (x <= 0 || x >= 800)
				velX *= -1;

		handler.addObject(new Trail((int) x, (int) y, ID.Trail, Color.GREEN, 16, 16, (float) 0.05, handler));

	}

}
