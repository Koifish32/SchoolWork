
public enum ID {
	
	Player(),
	MenuParticle,
	Trail,
	BasicEnemy,
	MediumEnemy,
	ComplexEnemy,
	BossOne,
	EnemyBullet,
	FroggerEnemy,
	Enemy();
	

}
