import java.awt.Graphics;
import java.util.ArrayList;
import java.util.LinkedList;

//Maintain objects.

public class Handler {
	ArrayList<GameObject> object = new ArrayList<GameObject>();

	public void tick() {
		for (int i = 0; i < object.size(); i++) {
			GameObject tempObject = object.get(i);
			tempObject.tick();
		}
	}

	public void render(Graphics g) {
		for (int i = 0; i < object.size(); i++) {
			GameObject tempObject = object.get(i);
			tempObject.render(g);
		}
	}

	public void addObject(GameObject object) {
		this.object.add(object);
	}

	public void removeOBject(GameObject object) {
		this.object.remove(object);
	}

	public void clearEnemys() {

		float posX = Game.WIDTH / 2;
		float posY = 540;

		for (int i = 0; i < object.size(); i++) {
			GameObject tempObject = object.get(i);

			if (tempObject.getType() == "player") {
				posX = tempObject.getX();
				posY = tempObject.getY();
				break;
			}
		}

		object = new ArrayList<GameObject>();
		object.add(new Player((int) posX, (int) posY, ID.Player, this));

	}

	public void clear() {
		object = new ArrayList<GameObject>();
	}
}
