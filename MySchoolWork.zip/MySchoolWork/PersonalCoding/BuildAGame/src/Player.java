import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Random;
import java.awt.Rectangle;

public class Player extends GameObject {
	private Random r;
	Handler handler;

	public Player(int x, int y, ID id, Handler handler) {
		super(x, y, id, "player");
		this.handler = handler;

		r = new Random();

	}

	@Override
	public void tick() {
		x += velX;
		y += velY;

		x = Game.clamp(x, 0, Game.WIDTH - 32);
		y = Game.clamp(y, 0, Game.HEIGHT - 62);

		handler.addObject(new Trail((int)x, (int)y, ID.Trail, Color.CYAN, 32, 32, (float) 0.05, handler));

		// handler.addObject(new Trail(x,y,ID.Trail,Color.CYAN, 32, 32, (float)0.05,
		// handler));

		collision();

	}

	private void collision() {
		for (int i = 0; i < handler.object.size(); i++) {
			GameObject tempObject = handler.object.get(i);

			if (tempObject.getType() == "enemy") {
				if (getBounds().intersects(tempObject.getBounds())) {

					HUD.HEALTH--;
				}

			}
		}
	}

	@Override
	public void render(Graphics g) {

		if (id == ID.Player)
			g.setColor(Color.CYAN);

		g.fillRect((int)x, (int)y, 32, 32);

	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle((int)x, (int)y, 32, 32);
	}

}
