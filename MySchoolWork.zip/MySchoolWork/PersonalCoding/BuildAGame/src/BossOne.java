import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;
import java.util.Random;

public class BossOne extends GameObject {

	private Handler handler;
	private Random r = new Random();
	LinkedList<Color> colors = new LinkedList<Color>();
	private int timer1 = 80;
	private int timer2 = 50;
	private int complexLimit = 0;
	private int froggerLimit = 0;

	public BossOne(int x, int y, ID id, Handler handler) {
		super(x, y, id, "enemy");

		this.handler = handler;
		velX = 0;
		velY = 2;
	}

	@Override
	public void render(Graphics g) {
		g.setColor(Color.RED);
		g.fillRect((int) x, (int) y, 96, 96);
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle((int) x, (int) y, 96, 96);
	}

	@Override
	public void tick() {
		x += velX;
		y += velY;
		
		


		if (x <= 0 || x >= Game.WIDTH - 96)
			velX *= -1;

		if (timer1 <= 0) {
			velY = 0;
		} else
			timer1--;
		

		if (timer1 <= 0)
			timer2--;
		
		if(timer2 <= 0){
			if (velX == 0)
				velX = 2;
			int spawn = r.nextInt(8);
			if(spawn == 0) handler.addObject(new EnemyBullet((int)x, (int) y, ID.EnemyBullet, handler));
			
			for(int i = 0; i < handler.object.size(); i++) {
				GameObject tempObject = handler.object.get(i);
				if(tempObject.getType() == "player" && tempObject.getY() <= 20 && complexLimit < 2) {
					handler.addObject(new ComplexEnemy((int)x, (int) y, ID.ComplexEnemy, handler));
					complexLimit++;
				}
				
				if(tempObject.getType() == "player" && tempObject.getY() >= 500 && froggerLimit < 1) {
					handler.addObject(new FroggerEnemy((int)x, (int) y, ID.FroggerEnemy, handler));
					froggerLimit++;
				}
			}
			
		}
		

		handler.addObject(new Trail((int) x, (int) y, ID.Trail, Color.RED, 96, 96, (float) 0.05, handler));

	}

}
